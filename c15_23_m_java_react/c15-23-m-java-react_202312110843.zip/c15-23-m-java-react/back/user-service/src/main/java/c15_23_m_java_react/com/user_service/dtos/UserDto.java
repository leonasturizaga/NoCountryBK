package c15_23_m_java_react.com.user_service.dtos;

public class UserDto {

}
