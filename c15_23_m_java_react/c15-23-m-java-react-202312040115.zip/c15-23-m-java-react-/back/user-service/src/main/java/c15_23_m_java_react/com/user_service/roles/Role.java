package c15_23_m_java_react.com.user_service.roles;

public enum Role {
	USER,
	ADMIN;
}
