export const Form = () => {
    return (
        <>
            <h1>Form</h1>
            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Eaque quisquam nemo tempora fuga vero dolor, blanditiis minima quod eum totam iste architecto quasi consectetur, aspernatur odit beatae animi facere iusto?</p>
        </>
    )
}
